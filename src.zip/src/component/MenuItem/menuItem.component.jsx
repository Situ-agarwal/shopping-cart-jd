import React from 'react';
import {connect} from 'react-redux'
import {addItem,subtractItem} from '../Cart/cartActions';
import   './menuItems.styles.css'
class MenuItem extends React.Component{
    constructor(props){
        super(props);
        this.state={
            isButtonClick:false,
            count:0
        }
    }
    handleClick=(itemsToBeAdded)=>{
        this.props.addItem(itemsToBeAdded);
        this.setState({isButtonClick:true,count:this.state.count+1})
        
    }
    subtractItem=(product)=>{
        this.setState({count:this.state.count-1})
        this.props.subtractItem(product); 

    }
    addItem=(cartItemToAdd)=>{
        this.setState({count:this.state.count+1})
       this.props.addItem(cartItemToAdd);
    }
    render(){
        const {productItem}=this.props;
    return (
        <div className='collection-item'>
            <img
        className='image'
        src={productItem.imageUrl} alt={productItem.name}      
      />        
            <div className='collection-footer'>
            <span className='title'>{productItem.name}</span> 
            <div className='price'><i class="fa fa-inr" aria-hidden="true">{productItem.price}</i></div>
            {this.state.isButtonClick === true ?
             <span className='quantity'>
             <span className='arrow' onClick={() => this.subtractItem(productItem)}>
             &#8722;
             </span>
             <span className='value'>{this.state.count}</span>
             <span className='arrow' onClick={() => this.addItem(productItem)}>
             &#43;
             </span>
           </span>:
              <div className='add-button' onClick={()=>{this.handleClick(productItem)}}><i class="fa fa-plus-circle" aria-hidden="true">ADD</i></div>
            }
            
           </div>
            </div>
    )
    }}
    const mapDispatchToProps = dispatch => ({
        addItem: item => dispatch(addItem(item)),
        subtractItem:item => dispatch(subtractItem(item))
      });  
export default connect(undefined,mapDispatchToProps)(MenuItem);