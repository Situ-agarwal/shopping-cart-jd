import  React from 'react';
import { connect }  from 'react-redux';
import {fetchProducts} from './productActions'
import MenuItem from '../MenuItem/menuItem.component'
import './productList.styles.css'
class ProductList extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
          product: null,
        };}
    render(){
        console.log("sss",this.props.products)
        if(this.props.products!==undefined){
        return(
            <div className='collection-preview'>
                <div className='preview'>
                   {this.props.products.map(item=>(
                       <MenuItem productItem={item}></MenuItem>
                   ))}
                    </div>
         </div>
        )}
        else{return null}
    
}
    
}
export default connect((state) => ({ products: state.productReducer.product}),fetchProducts)(ProductList);