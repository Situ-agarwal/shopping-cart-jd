
export const productReducers = (state = {}, action) => {
    switch (action.type) {
      case 'FETCH_PRODUCTS':
           return { ...state, loading: true };
      case 'PRODUCTS_LIST':
           return { ...state, product: action.products, loading: false }
      default: 
           return state;
    }
   }