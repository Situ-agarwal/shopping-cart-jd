/* export const fetchProducts = () => {
    return({
      type: 'FETCH_PRODUCTS',
    });
  }; */
  export const fetchProducts = () => async (dispatch) => {
    const FETCH_PRODUCTS_LIST ='http://omega.jdomni.com/omni-automation-tools/training/getAllProducts?auth_key=6c55fa36a2138b23a52e74619bfdae147fa0c3e1&pageNo=1&itemsPerPage=10'
    
    const res = await fetch(FETCH_PRODUCTS_LIST);
    const data = await res.json();
    console.log(data);
    dispatch({
      type: 'PRODUCTS_LIST',
      products: data.products,
    });
  };  
