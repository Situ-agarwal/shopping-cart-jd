import React from 'react';
import { connect } from 'react-redux';
const getTotalCartItem=(itemCount)=>{
    const cartQuantity= itemCount.map(function(value) {
        return value.cartQuantity;
      })
      console.log('cartQty',cartQuantity.reduce((a, b) => a + b, 0)
      )
    return  cartQuantity.reduce((a, b) => a + b, 0)

}
const CartIcon = ({itemCount }) => {
    const cartItem=getTotalCartItem(itemCount);
    return(
  
  <div className='item-count'>{`Cart(${cartItem})`}</div>
    )};

const mapStateToProps = state=>({
  itemCount: state.cartItemsReducer.cartItems
});

export default connect(
  mapStateToProps,
  undefined
)(CartIcon);
