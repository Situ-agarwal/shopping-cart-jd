import React from 'react';
import {Link} from 'react-router-dom'
import { connect } from 'react-redux';
import axios from 'axios';
import './checkoutPage.styles.css';
import {clearCart,fetchCartData} from '../component/Cart/cartActions'
import CheckoutComp from '../component/Cart/checkout.component';
class CheckoutPage extends React.Component{
    componentDidMount(){
        axios.get('http://omega.jdomni.com/omni-automation-tools/training/getAllCartItems?auth_key=6c55fa36a2138b23a52e74619bfdae147fa0c3e1')
        .then(res =>{
            this.props.onInit(res.data);
           
          })
         
    }
    handleClick =()=>{
        console.log('ssad',this.props)
        this.props.clearCart();
    }
    render(){
        const {cartItems}=this.props;
        const priceArr=cartItems.map(function(value){
            return value.cartQuantity*value.price

        })
        const total=priceArr.reduce((a,b)=>a+b,0);
        console.log('price',total);
  return(
  <div className='checkout-page'>
    <div className='shopping'>
    <span className='shopping-item'>
         {`Shopping Cart (${cartItems.length} items)`} 
         <button className='remove-button' onClick={this.handleClick}>
      clearItem
      </button> 
      </span>  
      </div>
      <div className='checkout-header'>
      <div className='header-block'>
        <span className='item-details'>Item Details</span>
      </div>
      <div className='header-block'>
        <span className='quantity'>Quantity</span>
      </div>
      <div className='header-block'>
        <span className='rate'>Rate</span>
      </div>
      <div className='header-block'>
        <span className='amount'>Amount</span>
      </div>
    </div>
    {cartItems.length!==0 && 
    cartItems.map(cartItem => (
      <CheckoutComp key={cartItem.id} cartItem={cartItem} />
    ))}
    <div className='footer'>
    <div className='continue-shop'><Link className='continue-link'to='/'><span className='arrowicon'><i class="fa fa-arrow-left" aria-hidden="true"></i></span>Continue Shopping</Link></div>
    <span className='total'><span className='totaldef'>Amount Payable:</span><i class="fa fa-inr" aria-hidden="true">{total}</i></span>
    </div>
  </div>
  )}
}

const mapStateToProps = (state) => ({ cartItems: state.cartItemsReducer.cartItems,

})
const mapDispatchToProps = dispatch => ({
    clearCart: () => dispatch(clearCart()),
    onInit:(item)=>dispatch(fetchCartData(item))
  });


export default connect(mapStateToProps,mapDispatchToProps)(CheckoutPage);
