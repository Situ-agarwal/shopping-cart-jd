import React from 'react';
import ProductList from '../component/ProductList/productList.component'
const HomePage =()=>{
    return(
        <ProductList></ProductList>
    )
}

export default HomePage;